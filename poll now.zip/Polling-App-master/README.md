howCode Directus Polling App
============================

This is the source code for howCode's polling application, made using Directus. You can find the video that accompanies this source code here: https://www.youtube.com/watch?v=KlbNenEivkw
